from setuptools import setup, find_packages

setup(
    name='django-api-getway',
    version='0.0.5',
    keywords=('django', 'paynetgatewayapi', 'dataproxy'),
    description='paymentgateway for Django',
    license='Developers',
    author='Suman',
    author_email='sumanjha810@gmail.com',

    packages=find_packages(),
    include_package_data = True,
    install_requires=[]
)

