from django.apps import AppConfig


class PaymentsapiConfig(AppConfig):
    name = 'paymentsapi'
