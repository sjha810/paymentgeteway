import urllib
import urllib3
import json

url = 'https://sbpaymentservices.payfort.com/FortAPI/paymentApi'
arrData = {
'command':'VOID_AUTHORIZATION',
'access_code':'649f24c2',
'merchant_identifier':'CycHZxVj',
'merchant_reference':'XYZ9239-yu898',
'language':'en',
'signature':'7cad05f0212ed933c9a5d5dffa31661acf2c827a',
'order_description':'iPhone 6-S',
}

values = json.dumps(arrData)
data = urllib.urlencode(values)
req = urllib3.Request(url, data)
response = urllib3.urlopen(req)
page = response.read()