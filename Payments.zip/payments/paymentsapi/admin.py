from django.contrib import admin
from .models import Pay, ConApi

# Register your models here.
admin.site.register(Pay)
admin.site.register(ConApi)