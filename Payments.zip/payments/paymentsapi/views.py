from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from .models import ConApi
import requests, json, cgi
from django.views.decorators.csrf import csrf_exempt
# from PayFort import checksum
# Create your views here.
class paygateway(APIView):
    authentication_class =()

    def task(self, request):
        path = request.path_info.split('/')

        if len(path)<2:
            return Response("Bad Request", status=status.HTTP_400_BAD_REQUEST)

        # if card does't word
        apimodel = ConApi.objects.filter(name=path[1])
        if apimodel.count()!=1:
            return Response("Bad Request", status=status.HTTP_400_BAD_REQUEST)

        # one time work
        valid, msg = apimodel[0].check_payment(request)
        if not valid:
            return Response(msg, status=status.HTTP_400_REQUEST)

        res = apimodel[0].send-request(request)
        if res.headers.get('Content-Type', '').lower()=='application/json':
            data = res.json()

        else:
            data = res.content
        return Response(data=data, status=res.status_code)

    def get(self, request):
        return self.task(request)
    
    def post(self, request):
        return self.task(request)

    def put(self, request):
        return self.task(request)

    def skey(self, request):
        return self.task(request)

    def delete(self, request):
        return self.task(request)

def index(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')


        requestParams = {
            'command' : 'AUTHORIZATION',
            'access_code' : 'rxaCBohhRdmZopQxc4gu',
            'merchant_identifier' : '649f24c2',
            'merchant_reference' : 'XYZ9239-yu898',
            'amount' : '10000',
            'currency' : 'AED',
            'language' : 'en',
            'customer_email' : 'test@payfort.com',
            'signature' : '7cad05f0212ed933c9a5d5dffa31661acf2c827a',
            'order_description' : 'iPhone 6-S',
            'CALLBACK_URL':'http://127.0.0.1:8080/paymentsapi/handlerequest'
        }
        return render(request, 'payfort.html', {'requestParams': requestParams})

    return render(request, "index.html")

@csrf_exempt
def handlerequest(request):
    return HttpResponse('Payment Accepted')
    pass
