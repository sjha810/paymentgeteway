from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _
from rest_framework import HTTP_HEADER_ENCODING
from rest_framework.authentication import get_authorization_header,BasicAuthentication
import requests, json,uuid
from datetime import datetime


# Create your models here.
class Pay(models.Model):
    userid = models.TextField()
    cardkey = models.CharField(max_length=255)
    

    def __unicode__(self):
        return self.userid.username

    def __str__(self):
        return self.userid.username

class ConApi(models.Model):
    S_LISTS =(
        (0, _('Access user')),
        (1, _('Basic auth')),
        (2, _('Key auth')),
        (3, _('Server auth'))
    )

    name = models.CharField(max_length=255, unique=True)
    requests_path = models.CharField(max_length=255)
    upurl = models.CharField(max_length=255)
    con = models.IntegerField(choices=S_LISTS, default=0)
    payments = models.ManyToManyField(Pay, blank=True)

    def check_payment(self, request):
        if self.con == 0:
            return True, ''
        
        elif self.con == 1:
            auth = BasicAuthentication
            try:
                user, password =auth.authentcate(request)
            except:
                return False, 'Authentication Is Not Valid'

            if self.payment.filter(user=user):
                return True, ''            
            else:
                return False, 'Permission Not Allowed'

    def send_request(self, request):
        headers ={}
        if self.con !=1 and request.META.get('HTTP_AUTHORIZATION'):
            headers['authorization'] =request.META.get('HTTP_AUTHORIZATION')

        stripe ='/service' + self.request.path
        full_path = request.get_full_path()[len(stripe):]
        method = request.method.lower()
        Map={
            'get':'request.get',
            'post':'request.post',
            'put':'request.put',
            'skey':'request.skey',
            'delete':'request.delete',
        }
    def __unicode__(self):
        return self.name
    
    def __str__(self):
        return self.name

    # class customer_info(models.Model):
    #     STATUS_LISTS =(
    #     (0, _('Payments Type')),
    #     (1, _('Pending')),
    #     (2, _('Key auth')),
    # )

    #     date = models.DateTimeField(auto_now_add=True)
    #     amount = models.IntegerField()
    #     order_no = models.CharField(max_length=255, unique=True)
    #     udid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

